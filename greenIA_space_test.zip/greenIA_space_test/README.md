---
title: Détection d'anomalies avec des images
description: >-
  Projet de détection d'anomalies utilisant ResNet-50 pour l'extraction de
  caractéristiques et EllipticEnvelope pour la détection d'anomalies.
license: apache-2.0
sdk: streamlit
pinned: true
---

# Détection d'anomalies avec des images

Ce dépôt contient un projet de détection d'anomalies avec des images en utilisant un modèle ResNet-50 pour l'extraction de caractéristiques et un modèle EllipticEnvelope pour la détection d'anomalies.

## Instructions d'utilisation

1. Installez les dépendances: `pip install -r requirements.txt`
2. Exécutez le script principal: `python app.py`

## Dataset

Le dataset utilisé est `VisA_20220922.tar`, disponible sur Hugging Face Hub.

## Modèle

Le modèle de détection d'anomalies est un EllipticEnvelope entraîné sur les caractéristiques extraites par un modèle ResNet-50.

## Résultats

Les résultats de la prédiction sont sauvegardés dans le fichier `detection_results.csv`.
## Auteurs

Nicolas DIOUBATE
Esdras GBEDOZIN
Narjiss HAMMOUDI
Marc Junior HOUNDJI

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
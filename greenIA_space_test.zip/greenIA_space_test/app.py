import streamlit as st

# Titre de l'application
st.title("GreenIA - Hackathon")
st.subheader("🌿 Une IA plus frugale pour classifier les images 📷")

# Upload d'image
uploaded_file = st.file_uploader("📂 Chargez une image...", type=["jpg", "png", "jpeg"])

# Affichage de l'image et prédiction (exemple)
if uploaded_file:
    st.image(uploaded_file, caption="Image chargée.", use_column_width=True)
    st.write("🔄 Analyse en cours...")

    # Ici, tu peux ajouter ton modèle IA pour classifier l'image
    st.success("✅ Résultat : Image acceptée ou rejetée (exemple)")


from huggingface_hub import hf_hub_download
from datasets import Dataset
import tarfile
import os
import joblib
from utils import build_dataset, extract_features  # Importe les fonctions de utils.py
import matplotlib.pyplot as plt
import pandas as pd
from huggingface_hub import notebook_login
from huggingface_hub import login
import os
from sklearn.decomposition import PCA # Ajoute cet import
from sklearn.covariance import EllipticEnvelope

token = os.getenv("HF_TOKEN")

if token:
    login(token=token) # Passe le token directement à login
else:
    print("Warning: HF_TOKEN environment variable not set. Some features may not work.")

# --- Téléchargement et extraction des données ---
repo_id = "Team198523/dataset_image"
filename = "VisA_20220922.tar"
revision = "main"
extract_path = "VisA_20220922_extracted"

# Télécharger le fichier TAR
tar_path = hf_hub_download(repo_id=repo_id, filename=filename, repo_type="dataset", revision=revision)

# Extraire l'archive TAR
os.makedirs(extract_path, exist_ok=True)
with tarfile.open(tar_path, "r:*") as tar:
    tar.extractall(path=extract_path)

# --- Construction du dataset ---
dataset = build_dataset(extract_path)
dataset_split = dataset.train_test_split(test_size=0.7)  # ou 0.7, selon ton choix
train_dataset = dataset_split['train']
val_dataset = dataset_split['test']

# --- Chargement de toutes les images et extraction de caractéristiques ---
all_image_paths = train_dataset["image_path"]
all_features = extract_features(all_image_paths)

# --- Entraînement du détecteur d'anomalies ---
# Réduction de dimension avec PCA
pca = PCA(n_components=min(all_features.shape[0], all_features.shape[1]) - 1) 
features_reduced = pca.fit_transform(all_features)

# Entraînement du modèle avec les données réduites (toutes les images)
anomaly_detector = EllipticEnvelope(contamination=0.01)
anomaly_detector.fit(features_reduced)

# --- Sauvegarde des modèles ---
joblib.dump(anomaly_detector, "models/anomaly_detector.pkl")
joblib.dump(pca, "models/pca_transformer.pkl")

# --- Prédiction et évaluation ---
# --- Chargement de toutes les images de validation pour la prédiction ---
val_image_paths = val_dataset["image_path"]

# Extraire les caractéristiques des images de validation
test_features = extract_features(val_image_paths)

# Charger le PCA sauvegardé et appliquer la transformation sur les données de test
pca = joblib.load("models/pca_transformer.pkl")
test_features_reduced = pca.transform(test_features)

# Charger le détecteur d’anomalies sauvegardé
anomaly_detector = joblib.load("models/pca_transformer.pkl")

# Prédire les scores d'anomalie
anomaly_scores = anomaly_detector.decision_function(test_features_reduced)

# Exemple : définir un seuil (ici, basé sur le 5e percentile des scores des images normales)
threshold = np.percentile(anomaly_scores, 95)  # À ajuster en fonction de ton dataset

# Classifier chaque image : anomalie si le score < seuil
predictions = anomaly_scores < threshold

# Afficher les résultats
for img_path, score, pred in zip(val_image_paths, anomaly_scores, predictions):
    status = "Anomalie" if pred else "Normale"
    print(f"{img_path}: {status} (score: {score:.2f})")

# Labels réels : 1 pour anomalie, 0 pour normal
true_labels = val_dataset["label"]  # Labels du dataset de validation

# Calcul du score AUROC
auc = roc_auc_score(true_labels, -anomaly_scores)  # On inverse car les scores négatifs indiquent des anomalies
print(f"AUROC Score: {auc:.4f}")

# --- Visualisation et sauvegarde des résultats ---
plt.figure(figsize=(10, 5))
plt.hist(anomaly_scores, bins=50, alpha=0.75, color='blue', label="Scores d'anomalie")
plt.axvline(threshold, color='red', linestyle='dashed', linewidth=2, label="Seuil")
plt.xlabel("Score d'anomalie")
plt.ylabel("Nombre d'images")
plt.legend()
plt.title("Distribution des scores d'anomalie")
plt.show()

# Création d'un dataframe avec les résultats
results_df = pd.DataFrame({
    "image_path": val_image_paths,  # Remplace anomaly_image_paths par val_image_paths
    "anomaly_score": anomaly_scores,
    "prediction": ["Anomalie" if pred else "Normale" for pred in predictions]
})

results_df.to_csv("detection_results.csv", index=False)
print("Rapport des anomalies sauvegardé dans 'detection_results.csv'")


candle_path = "VisA_20220922_extracted/candle/Data/Images"

# Sélectionner une image aléatoire en parcourant les sous-dossiers
all_images = []
for root, _, files in os.walk(candle_path):
    for file in files:
        if file.lower().endswith(('.png', '.jpg', '.jpeg')):
            all_images.append(os.path.join(root, file))  

if not all_images:
    print("Aucune image trouvée dans le dossier candle.")
else:
        random_image_path = random.choice(all_images)  # Sélectionner un chemin d'accès aléatoire
        random_image = os.path.basename(random_image_path)  # Extraire le nom du fichier
        image = Image.open("random_image_path")
        plt.imshow(image)
        plt.axis("off")
        plt.show()

try:
        # Charger toutes les images pour le calcul du seuil
        all_image_paths = all_images
        all_features_for_threshold = extract_features(all_image_paths)

        # Analyser l'image sélectionnée
        result, anomaly_score = analyze_image(random_image_path, all_features_for_threshold)

        # Afficher le résultat
        print(f"L'image {random_image} est classée comme {result} (score d'anomalie : {anomaly_score:.2f})")
except Exception as e:
        print(f"Erreur lors du test de l'image : {e}")